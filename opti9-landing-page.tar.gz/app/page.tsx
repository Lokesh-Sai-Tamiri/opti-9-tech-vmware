"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { CheckCircle, ArrowRight, Download, Shield, TrendingUp, Users, Award, Clock, X } from "lucide-react"
import Image from "next/image"
import { useState } from "react"

export default function VMwareLandingPage() {
  const [isLeadFormOpen, setIsLeadFormOpen] = useState(false)
  const [isConsultationOpen, setIsConsultationOpen] = useState(false)
  const [leadFormData, setLeadFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    company: '',
    phone: '',
    message: ''
  })

  const handleLeadFormSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // Here you would typically send the data to your backend
    console.log('Lead form submitted:', leadFormData)
    // Simulate download
    alert('Thank you! Your case study download will begin shortly.')
    setIsLeadFormOpen(false)
    // Reset form
    setLeadFormData({
      firstName: '',
      lastName: '',
      email: '',
      company: '',
      phone: '',
      message: ''
    })
  }

  const openHubSpotMeeting = () => {
    window.open('https://meetings.hubspot.com/drew-jenkins1', '_blank', 'width=800,height=600')
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-white">
      {/* Header */}
      <header className="border-b bg-white/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <div className="flex space-x-1">
              <div className="w-2 h-2 bg-blue-600 rounded-full"></div>
              <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
              <div className="w-2 h-2 bg-blue-400 rounded-full"></div>
            </div>
            <span className="text-2xl font-bold text-slate-800">opti9</span>
          </div>
          <div className="flex items-center space-x-4">
            <Badge variant="secondary" className="bg-blue-100 text-blue-800">
              AWS Premier Tier Partner
            </Badge>
            <Button variant="outline" onClick={openHubSpotMeeting}>Contact Us</Button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-20 px-4">
        <div className="container mx-auto max-w-6xl">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <Badge className="mb-4 bg-red-100 text-red-800 border-red-200">
                VMware Licensing Crisis
              </Badge>
              <h1 className="text-5xl font-bold text-slate-900 mb-6 leading-tight">
                Escape the 40% VMware 
                <span className="text-blue-600"> Licensing Increase</span>
              </h1>
              <p className="text-xl text-slate-600 mb-8 leading-relaxed">
                Following Broadcom's acquisition, VMware licensing costs are skyrocketing. 
                Transform this challenge into an opportunity to modernize with AWS.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Dialog open={isLeadFormOpen} onOpenChange={setIsLeadFormOpen}>
                  <DialogTrigger asChild>
                    <Button size="lg" className="bg-blue-600 hover:bg-blue-700">
                      <Download className="mr-2 h-5 w-5" />
                      Download Case Study
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="sm:max-w-[425px]">
                    <DialogHeader>
                      <DialogTitle>Download Case Study</DialogTitle>
                      <DialogDescription>
                        Get your free copy of the Pulse Health & LensDirect case study. Please fill out the form below.
                      </DialogDescription>
                    </DialogHeader>
                    <form onSubmit={handleLeadFormSubmit} className="space-y-4">
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <Label htmlFor="firstName">First Name *</Label>
                          <Input
                            id="firstName"
                            value={leadFormData.firstName}
                            onChange={(e) => setLeadFormData({...leadFormData, firstName: e.target.value})}
                            required
                          />
                        </div>
                        <div>
                          <Label htmlFor="lastName">Last Name *</Label>
                          <Input
                            id="lastName"
                            value={leadFormData.lastName}
                            onChange={(e) => setLeadFormData({...leadFormData, lastName: e.target.value})}
                            required
                          />
                        </div>
                      </div>
                      <div>
                        <Label htmlFor="email">Email *</Label>
                        <Input
                          id="email"
                          type="email"
                          value={leadFormData.email}
                          onChange={(e) => setLeadFormData({...leadFormData, email: e.target.value})}
                          required
                        />
                      </div>
                      <div>
                        <Label htmlFor="company">Company *</Label>
                        <Input
                          id="company"
                          value={leadFormData.company}
                          onChange={(e) => setLeadFormData({...leadFormData, company: e.target.value})}
                          required
                        />
                      </div>
                      <div>
                        <Label htmlFor="phone">Phone</Label>
                        <Input
                          id="phone"
                          value={leadFormData.phone}
                          onChange={(e) => setLeadFormData({...leadFormData, phone: e.target.value})}
                        />
                      </div>
                      <div>
                        <Label htmlFor="message">How can we help?</Label>
                        <Textarea
                          id="message"
                          value={leadFormData.message}
                          onChange={(e) => setLeadFormData({...leadFormData, message: e.target.value})}
                          placeholder="Tell us about your VMware challenges..."
                        />
                      </div>
                      <Button type="submit" className="w-full bg-blue-600 hover:bg-blue-700">
                        Download Case Study
                      </Button>
                    </form>
                  </DialogContent>
                </Dialog>
                <Button size="lg" variant="outline" onClick={openHubSpotMeeting}>
                  Get Free Assessment
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Button>
              </div>
            </div>
            <div className="relative">
              <Card className="p-6 bg-white shadow-xl">
                <div className="text-center">
                  <div className="text-4xl font-bold text-red-600 mb-2">40%</div>
                  <div className="text-slate-600 mb-4">VMware Licensing Increase</div>
                  <Separator className="my-4" />
                  <div className="text-2xl font-bold text-green-600 mb-2">$0</div>
                  <div className="text-slate-600">Additional AWS Migration Costs*</div>
                  <div className="text-sm text-slate-500 mt-2">*With AWS funding programs</div>
                </div>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Customer Logos Section */}
      <section className="py-16 bg-white border-y">
        <div className="container mx-auto max-w-6xl px-4">
          <div className="text-center mb-12">
            <h2 className="text-2xl font-bold text-slate-900 mb-2">
              Trusted by Over 25k+ Customers
            </h2>
            <p className="text-slate-600">
              Join thousands of companies who have modernized their infrastructure with Opti9
            </p>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-8 items-center justify-items-center opacity-60 hover:opacity-100 transition-opacity">
            <div className="flex items-center justify-center h-16">
              <Image src="/logos/logo1.png" alt="Customer Logo" width={120} height={60} className="max-h-12 w-auto object-contain" />
            </div>
            <div className="flex items-center justify-center h-16">
              <Image src="/logos/logo2.png" alt="Customer Logo" width={120} height={60} className="max-h-12 w-auto object-contain" />
            </div>
            <div className="flex items-center justify-center h-16">
              <Image src="/logos/logo3.png" alt="Customer Logo" width={120} height={60} className="max-h-12 w-auto object-contain" />
            </div>
            <div className="flex items-center justify-center h-16">
              <Image src="/logos/logo4.png" alt="Customer Logo" width={120} height={60} className="max-h-12 w-auto object-contain" />
            </div>
            <div className="flex items-center justify-center h-16">
              <Image src="/logos/logo5.png" alt="Customer Logo" width={120} height={60} className="max-h-12 w-auto object-contain" />
            </div>
            <div className="flex items-center justify-center h-16">
              <Image src="/logos/logo6.png" alt="Customer Logo" width={120} height={60} className="max-h-12 w-auto object-contain" />
            </div>
          </div>
        </div>
      </section>

      {/* Social Proof */}
      <section className="py-16 bg-slate-50">
        <div className="container mx-auto max-w-6xl px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-slate-900 mb-4">
              Trusted by Companies Like Yours
            </h2>
            <p className="text-slate-600">
              See how Pulse Health & LensDirect escaped VMware costs and modernized with AWS
            </p>
          </div>
          
          <Card className="p-8 bg-white shadow-lg">
            <div className="grid md:grid-cols-2 gap-8 items-center">
              <div>
                <div className="flex items-center mb-4">
                  <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mr-4">
                    <Users className="h-6 w-6 text-blue-600" />
                  </div>
                  <div>
                    <div className="font-semibold text-slate-900">Pulse Health & LensDirect</div>
                    <div className="text-slate-600">Life Science Tech & Vision Care</div>
                  </div>
                </div>
                <blockquote className="text-slate-700 italic mb-4">
                  "Opti9 helped us turn that challenge into an opportunity to modernize by migrating to AWS. 
                  We were able to remove, and in some cases consolidate and/or upgrade, over 60 servers."
                </blockquote>
                <div className="font-semibold text-slate-900">Robert Reynolds, CTO</div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="text-center p-4 bg-slate-50 rounded-lg">
                  <div className="text-2xl font-bold text-blue-600">60+</div>
                  <div className="text-sm text-slate-600">Servers Migrated</div>
                </div>
                <div className="text-center p-4 bg-slate-50 rounded-lg">
                  <div className="text-2xl font-bold text-green-600">40%</div>
                  <div className="text-sm text-slate-600">Cost Increase Avoided</div>
                </div>
                <div className="text-center p-4 bg-slate-50 rounded-lg">
                  <div className="text-2xl font-bold text-purple-600">$10K+</div>
                  <div className="text-sm text-slate-600">AWS Funding Received</div>
                </div>
                <div className="text-center p-4 bg-slate-50 rounded-lg">
                  <div className="text-2xl font-bold text-orange-600">100%</div>
                  <div className="text-sm text-slate-600">Uptime Maintained</div>
                </div>
              </div>
            </div>
          </Card>
        </div>
      </section>

      {/* Problem/Solution */}
      <section className="py-20 px-4">
        <div className="container mx-auto max-w-6xl">
          <div className="grid lg:grid-cols-2 gap-16">
            {/* Problem */}
            <div>
              <h2 className="text-3xl font-bold text-slate-900 mb-8">The VMware Challenge</h2>
              <div className="space-y-6">
                <Card className="p-6 border-red-200 bg-red-50">
                  <div className="flex items-start space-x-4">
                    <div className="w-8 h-8 bg-red-100 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                      <TrendingUp className="h-4 w-4 text-red-600" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-slate-900 mb-2">40% Licensing Increase</h3>
                      <p className="text-slate-600">Broadcom's acquisition has led to substantial cost hikes threatening IT budgets.</p>
                    </div>
                  </div>
                </Card>
                
                <Card className="p-6 border-orange-200 bg-orange-50">
                  <div className="flex items-start space-x-4">
                    <div className="w-8 h-8 bg-orange-100 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                      <Clock className="h-4 w-4 text-orange-600" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-slate-900 mb-2">Fixed Resources</h3>
                      <p className="text-slate-600">ESXi hosts provide limited capacity that can't easily scale with business demands.</p>
                    </div>
                  </div>
                </Card>
                
                <Card className="p-6 border-yellow-200 bg-yellow-50">
                  <div className="flex items-start space-x-4">
                    <div className="w-8 h-8 bg-yellow-100 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                      <Shield className="h-4 w-4 text-yellow-600" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-slate-900 mb-2">Hardware Dependencies</h3>
                      <p className="text-slate-600">Adding capacity requires purchasing new hardware, creating capital-intensive growth.</p>
                    </div>
                  </div>
                </Card>
              </div>
            </div>

            {/* Solution */}
            <div>
              <h2 className="text-3xl font-bold text-slate-900 mb-8">The AWS Solution</h2>
              <div className="space-y-6">
                <Card className="p-6 border-green-200 bg-green-50">
                  <div className="flex items-start space-x-4">
                    <CheckCircle className="h-6 w-6 text-green-600 flex-shrink-0 mt-1" />
                    <div>
                      <h3 className="font-semibold text-slate-900 mb-2">Cost Avoidance</h3>
                      <p className="text-slate-600">Escape VMware licensing increases while maintaining comparable IT spending.</p>
                    </div>
                  </div>
                </Card>
                
                <Card className="p-6 border-blue-200 bg-blue-50">
                  <div className="flex items-start space-x-4">
                    <CheckCircle className="h-6 w-6 text-blue-600 flex-shrink-0 mt-1" />
                    <div>
                      <h3 className="font-semibold text-slate-900 mb-2">Elastic Scalability</h3>
                      <p className="text-slate-600">Scale resources up and down as needed, eliminating hardware refresh cycles.</p>
                    </div>
                  </div>
                </Card>
                
                <Card className="p-6 border-purple-200 bg-purple-50">
                  <div className="flex items-start space-x-4">
                    <CheckCircle className="h-6 w-6 text-purple-600 flex-shrink-0 mt-1" />
                    <div>
                      <h3 className="font-semibold text-slate-900 mb-2">AWS Funding Support</h3>
                      <p className="text-slate-600">Offset implementation costs through AWS Migration Acceleration Program (MAP).</p>
                    </div>
                  </div>
                </Card>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Services */}
      <section className="py-20 bg-slate-50 px-4">
        <div className="container mx-auto max-w-6xl">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-slate-900 mb-4">
              Comprehensive AWS Migration Services
            </h2>
            <p className="text-xl text-slate-600">
              From assessment to ongoing management, we handle every aspect of your cloud journey
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            <Card className="p-6 bg-white shadow-lg hover:shadow-xl transition-shadow">
              <CardHeader className="pb-4">
                <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mb-4">
                  <Award className="h-6 w-6 text-blue-600" />
                </div>
                <CardTitle className="text-xl">Migration Strategy</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 text-slate-600">
                  <li className="flex items-center"><CheckCircle className="h-4 w-4 text-green-500 mr-2" />Assessment & Planning</li>
                  <li className="flex items-center"><CheckCircle className="h-4 w-4 text-green-500 mr-2" />Multi-account Architecture</li>
                  <li className="flex items-center"><CheckCircle className="h-4 w-4 text-green-500 mr-2" />Security Implementation</li>
                </ul>
              </CardContent>
            </Card>

            <Card className="p-6 bg-white shadow-lg hover:shadow-xl transition-shadow">
              <CardHeader className="pb-4">
                <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mb-4">
                  <Users className="h-6 w-6 text-green-600" />
                </div>
                <CardTitle className="text-xl">Server Migration</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 text-slate-600">
                  <li className="flex items-center"><CheckCircle className="h-4 w-4 text-green-500 mr-2" />60+ Servers Migrated</li>
                  <li className="flex items-center"><CheckCircle className="h-4 w-4 text-green-500 mr-2" />Right-sizing & Optimization</li>
                  <li className="flex items-center"><CheckCircle className="h-4 w-4 text-green-500 mr-2" />Zero Downtime Migration</li>
                </ul>
              </CardContent>
            </Card>

            <Card className="p-6 bg-white shadow-lg hover:shadow-xl transition-shadow">
              <CardHeader className="pb-4">
                <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mb-4">
                  <Shield className="h-6 w-6 text-purple-600" />
                </div>
                <CardTitle className="text-xl">CloudOps Management</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 text-slate-600">
                  <li className="flex items-center"><CheckCircle className="h-4 w-4 text-green-500 mr-2" />24/7 Monitoring</li>
                  <li className="flex items-center"><CheckCircle className="h-4 w-4 text-green-500 mr-2" />Disaster Recovery</li>
                  <li className="flex items-center"><CheckCircle className="h-4 w-4 text-green-500 mr-2" />Cost Optimization</li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-blue-600 text-white px-4">
        <div className="container mx-auto max-w-4xl text-center">
          <h2 className="text-4xl font-bold mb-6">
            Ready to Escape VMware Licensing Costs?
          </h2>
          <p className="text-xl mb-8 text-blue-100">
            Download our detailed case study and see how Pulse Health & LensDirect 
            successfully migrated 60+ servers to AWS while avoiding a 40% cost increase.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Dialog open={isLeadFormOpen} onOpenChange={setIsLeadFormOpen}>
              <DialogTrigger asChild>
                <Button size="lg" className="bg-white text-blue-600 hover:bg-gray-100">
                  <Download className="mr-2 h-5 w-5" />
                  Download Case Study
                </Button>
              </DialogTrigger>
            </Dialog>
            <Button size="lg" variant="outline" className="border-white text-white hover:bg-white hover:text-blue-600" onClick={openHubSpotMeeting}>
              Schedule Free Consultation
              <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
          </div>
        </div>
      </section>

      {/* Book a Consultation Section */}
      <section className="py-20 bg-slate-50 px-4">
        <div className="container mx-auto max-w-4xl">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-slate-900 mb-4">
              Book a Free Consultation
            </h2>
            <p className="text-xl text-slate-600">
              Speak with our AWS experts about your VMware migration strategy
            </p>
          </div>
          
          <Card className="p-8 bg-white shadow-lg">
            <div className="grid md:grid-cols-2 gap-8 items-center">
              <div>
                <h3 className="text-2xl font-bold text-slate-900 mb-4">What You'll Get:</h3>
                <ul className="space-y-3 text-slate-600">
                  <li className="flex items-center">
                    <CheckCircle className="h-5 w-5 text-green-500 mr-3" />
                    Free VMware cost analysis
                  </li>
                  <li className="flex items-center">
                    <CheckCircle className="h-5 w-5 text-green-500 mr-3" />
                    AWS migration roadmap
                  </li>
                  <li className="flex items-center">
                    <CheckCircle className="h-5 w-5 text-green-500 mr-3" />
                    Funding opportunities assessment
                  </li>
                  <li className="flex items-center">
                    <CheckCircle className="h-5 w-5 text-green-500 mr-3" />
                    Custom solution recommendations
                  </li>
                </ul>
                <div className="mt-6">
                  <Button size="lg" className="bg-blue-600 hover:bg-blue-700" onClick={openHubSpotMeeting}>
                    Schedule Your Consultation
                    <ArrowRight className="ml-2 h-5 w-5" />
                  </Button>
                </div>
              </div>
              <div className="bg-slate-50 p-6 rounded-lg">
                <div className="text-center">
                  <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Users className="h-8 w-8 text-blue-600" />
                  </div>
                  <h4 className="text-lg font-semibold text-slate-900 mb-2">Meet with Drew Jenkins</h4>
                  <p className="text-slate-600 mb-4">AWS Solutions Architect</p>
                  <div className="text-sm text-slate-500">
                    <p>✓ 30-minute consultation</p>
                    <p>✓ No sales pressure</p>
                    <p>✓ Actionable insights</p>
                  </div>
                </div>
              </div>
            </div>
          </Card>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-slate-900 text-white py-12 px-4">
        <div className="container mx-auto max-w-6xl">
          <div className="grid md:grid-cols-3 gap-8">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <div className="flex space-x-1">
                  <div className="w-2 h-2 bg-blue-400 rounded-full"></div>
                  <div className="w-2 h-2 bg-blue-300 rounded-full"></div>
                  <div className="w-2 h-2 bg-blue-200 rounded-full"></div>
                </div>
                <span className="text-2xl font-bold">opti9</span>
              </div>
              <p className="text-slate-400 mb-4">
                AWS Premier Tier Partner helping companies modernize their infrastructure for over 10 years.
              </p>
              <div className="flex space-x-4">
                <Badge variant="secondary" className="bg-slate-800 text-slate-300">
                  Migration & Modernization
                </Badge>
                <Badge variant="secondary" className="bg-slate-800 text-slate-300">
                  DevOps
                </Badge>
              </div>
            </div>
            
            <div>
              <h3 className="font-semibold mb-4">Services</h3>
              <ul className="space-y-2 text-slate-400">
                <li>AWS Migration</li>
                <li>CloudOps Management</li>
                <li>Database Modernization</li>
                <li>Serverless Architecture</li>
              </ul>
            </div>
            
            <div>
              <h3 className="font-semibold mb-4">Contact</h3>
              <div className="text-slate-400 space-y-2">
                <p>1010 N. 102nd St. Ste 201A</p>
                <p>Omaha, NE 68114</p>
                <p>Opti9tech.com</p>
              </div>
            </div>
          </div>
          
          <Separator className="my-8 bg-slate-800" />
          
          <div className="text-center text-slate-400">
            <p>&copy; 2024 Opti9 Technologies. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
